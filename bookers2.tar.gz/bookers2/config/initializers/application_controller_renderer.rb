# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'e040635792038ce57f5f830f74fd17861cb40de78a58e43f064a7e3fd03232f87c1cb8fd804efe44a869063cc4f48f69f808fb1ea01d851194d06e8c4bf61a46'
